#include "timer.h"

#include <QtCore>
#include <QDebug>

timer::timer()
{
    timerz = new QTimer(this);
    connect(timerz,SIGNAL(timeout()), this, SLOT(my))
}
