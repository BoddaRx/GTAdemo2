#include "player.h"
#include <QDebug>
#include <QProcess>
#include "bullet.h"
#include "enemy.h"
#include "pellet.h"
#include <QTimer>
#include "health.h"
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QTime>
#include <QObject>
#include "gameover.h"
#include "display.h"
#include "gate.h"
#include <QApplication>
#include "win.h"
#include "timer.h"

void Player::keyPressEvent(QKeyEvent* event)
{

    int boardData[15][15];

    qDebug() << "moving...";

    //4 arrows of movement
    if (event->key() == Qt::Key_Up && data[row - 1][column] > 0)
    {
        row--;
    }
    else if (event->key() == Qt::Key_Down && data[row + 1][column] > 0)
    {
        row++;
    }
    else if (event->key() == Qt::Key_Right && data[row][column + 1] > 0)
    {
        column++;
    }
    else if (event->key() == Qt::Key_Left && data[row][column - 1] > 0)
    {
        column--;
    }
    setPos(50 + column * 50, 50 + row * 50);

    //Muscular Player
    QPixmap spongePellet("/Users/AbdelrahmanNashed/downloads/GTA/spongePellet.png");
    spongePellet = spongePellet.scaledToWidth(50);
    spongePellet = spongePellet.scaledToHeight(50);

    //Shooting Player
    QPixmap spongeBullet("/Users/AbdelrahmanNashed/downloads/GTA/spongeBullet1.png");
    spongeBullet = spongeBullet.scaledToWidth(50);
    spongeBullet = spongeBullet.scaledToHeight(50);

    //main player
    QPixmap image("/Users/AbdelrahmanNashed/downloads/GTA/sponge.png");
    image = image.scaledToWidth(50);
    image = image.scaledToHeight(50);


    QList<QGraphicsItem*> items = collidingItems();
    for (int i = 0; i < items.size(); i++)
    {
        //If the player collides with a bullet, the bullet disapears
        if (typeid(*items[i]) == typeid(bullet))
        {
            this -> bulletCount--;

        scene()->removeItem(items[i]);

        setPixmap(spongeBullet);

        QTimer* timer5 = new QTimer(this);
        timer5->start(1000);

//        connect(timer5,SIGNAL(timeout()), this,SLOT(QTime::currentTime().toString("hh:mm:ss")));

        connect(timer5, &QTimer::timeout, [=]() {

                setPixmap(image);
    });

        if(bulletCount == 3)
        {
            qDebug() << "Enemy 1 now has a half life";
        }

        else if(bulletCount == 2)
        {
            this -> enemyCount--;
        qDebug() << "Enemy 1 now is dead";
        scene() -> removeItem(this->enemyArr[0]);
        }

        else if (bulletCount == 1)
        {
            qDebug() << "Enemy 2 now has a half life";
        }
        else if (bulletCount == 0)
        {
            this -> enemyCount--;
            qDebug() << "Enemy 2 now is dead";
            scene() -> removeItem(this->enemyArr[1]);

            gate *g1 = new gate(boardData,11,6);
            scene()->addItem(g1);
        }
        }

        //If the player collides with a pellet, his shape changes and become powerful and unaffected by his enemies
        else if (typeid(*items[i]) == typeid(pellet))
        {
            this -> pelletCount--;
            qDebug() << "SpongeBob now is immortal and powerful";
            scene() -> removeItem(items[i]);



            if (pelletCount == 1)
            {
                setPixmap(spongePellet);
                display *d1 = new display(boardData,0,14);
                scene()->addItem(d1);

            QTimer* timer3 = new QTimer(this);
//            QTime time = QTime::fromString("23:54", "hh:mm");

//            connect(timer3, &QTimer::timeout, [&time](){
//                    time = time.addSecs(-1);
//                    qDebug()<<time.toString("hh:mm:ss");
//                });

//            connect(timer3,SIGNAL(timeout()),SLOT(QTime::currentTime().toString("hh:mm:ss")));

            timer3->start(5000);

            timerx *t1 = new timerx(boardData,0,0);
            scene()->addItem(t1);

            connect(timer3, &QTimer::timeout, [=]() {
                qDebug() << "SpongeBob became normal again";
                scene()->removeItem(d1);
                scene()->removeItem(t1);
                    setPixmap(image);
                    timer3->stop();
        });
            }else if(pelletCount == 0)
            {
                setPixmap(spongePellet);

                display *d2 = new display(boardData,0,14);
                scene()->addItem(d2);

                timerx *t2 = new timerx(boardData,0,0);
                scene()->addItem(t2);

                QTimer* timer4 = new QTimer(this);
//                connect(timer4,SIGNAL(timeout()),this,SLOT());

                timer4->setInterval(5000);
                timer4->start();

                connect(timer4, &QTimer::timeout, [=]() {
                    scene()->removeItem(d2);
                    scene()->removeItem(t2);
                        setPixmap(image);
                        qDebug() << "SpongeBob became normal again";
                        timer4->stop();
            });
            }
        }

        //If the player collides with an enemy, he loses health and start from the begining till he loses the game
        else if (typeid(*items[i]) == typeid(Enemy))
        {

            this -> playerHealth--;

            if(playerHealth == 2)
            {
                this->row=7;
                this->column=7;
                this->setPos(50 + column * 50, 50 + row * 50);

                if(enemyCount == 1)
                {
                    scene() -> addItem(this->enemyArr[0]);
                        this->enemyCount++;

                }

                for (int i = 0; i < 15; i++)
                    for (int j = 0; j < 15; j++)
                    {
                if(boardData[i][j] != 122)
                {
                    bullet *b5 = new bullet(boardData,1,1);
                    scene()->addItem(b5);
                    bulletCount++;
                }

                if(boardData[i][j] != 12)
                {
                    bullet *b6 = new bullet(boardData,1,13);
                    scene()->addItem(b6);
                    bulletCount++;
                }

                if(boardData[i][j] != 113)
                {
                    bullet *b7 = new bullet(boardData,12,1);
                    scene()->addItem(b7);
                    bulletCount++;

                }

                if(boardData[i][j] != 121)
                {
                    bullet *b8 = new bullet(boardData,12,13);
                    scene()->addItem(b8);
                    bulletCount++;
                }

                if(boardData[i][j] != 24)
                {
                    pellet *b3 = new pellet(boardData,3,3);
                    scene()->addItem(b3);
                    pelletCount++;
                }

                if(boardData[i][j] != 75)
                {
                    pellet *b4 = new pellet(boardData,8,8);
                    scene()->addItem(b4);
                    pelletCount++;
                }
                    }

//for(int i=0; i<4; i++)
//{
//    qDebug()<< this->barr[i]->row;

////    this->s->addItem(this->barr[i]);
//}
        qDebug() << "Your player now has two lives left";

//        Player *play = new Player(boardData, *arr);
//        play -> setFlag(QGraphicsItem :: ItemIsFocusable);
//        play -> setFocus();
//        scene()->addItem(play);

        health *h1 = new health(boardData,14,12);
        scene()->addItem(h1);
//we just need to call main.cpp here



            }
            else if (playerHealth == 1)
            {
//                removeFromIndex();

                qDebug() << "Your player now has 1 life left";

                this->row=7;
                this->column=7;
                this->setPos(50 + column * 50, 50 + row * 50);
//                Player *play2 = new Player(boardData, *arr);
//                play2 -> setFlag(QGraphicsItem :: ItemIsFocusable);
//                play2 -> setFocus();
//                scene()->addItem(play2);

                for (int i = 0; i < 15; i++)
                    for (int j = 0; j < 15; j++)
                    {
                if(boardData[i][j] != 122)
                {
                    bullet *b5 = new bullet(boardData,1,1);
                    scene()->addItem(b5);
                    bulletCount++;
                }

                if(boardData[i][j] != 12)
                {
                    bullet *b6 = new bullet(boardData,1,13);
                    scene()->addItem(b6);
                    bulletCount++;
                }

                if(boardData[i][j] != 113)
                {
                    bullet *b7 = new bullet(boardData,12,1);
                    scene()->addItem(b7);
                    bulletCount++;

                }

                if(boardData[i][j] != 121)
                {
                    bullet *b8 = new bullet(boardData,12,13);
                    scene()->addItem(b8);
                    bulletCount++;
                }

                if(boardData[i][j] != 24)
                {
                    pellet *b3 = new pellet(boardData,3,3);
                    scene()->addItem(b3);
                    pelletCount++;
                }

                if(boardData[i][j] != 75)
                {
                    pellet *b4 = new pellet(boardData,8,8);
                    scene()->addItem(b4);
                    pelletCount++;
                }
                    }

                health *h2 = new health(boardData,14,13);
                scene()->addItem(h2);

            }
            else if (playerHealth == 0)
            {
                qDebug() << "GAME OVER";

//                health *h3 = new health(boardData,14,14);
//                scene()->addItem(h3);
//                QApplication::quit();

                gameover *g1 = new gameover(boardData,0,0);
                scene()->addItem(g1);

//                setPixmap(gameover);
            }

        }
        else if (typeid(*items[i]) == typeid(gate))
        {
            win *w1 = new win(boardData,0,0);
            scene()->addItem(w1);
            qDebug() << "YOU WON!";
        }
    }

}
