#include "enemy.h"
//#include "player.h"


void Enemy::moveEnemy()
{
    int m = rand()%4;
//    QList<QGraphicsItem*> items = collidingItems();
//    for (int i = 0; i < items.size(); i++)
//    {
//        if (typeid(*items[i]) == typeid(Player)){
//             column =4;
//             row = 3;
//        }
//    }
    if (m==0 && data[row - 1][column] > 0)
    {
        row--;
    }
    else if (m==1 && data[row + 1][column] > 0)
    {
        row++;
    }
    else if (m==2 && data[row][column + 1] > 0)
    {
        column++;
    }
    else if (m==3 && data[row][column - 1] > 0)
    {
        column--;
    }
    setPos(50 + column * 50, 50 + row * 50);


}
