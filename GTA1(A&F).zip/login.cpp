//#include "login.h"
//#include "main.h"

//login::login(QWidget *parent) :
//    QDialog(parent),
//    ui(new Ui::login)
//{
//    ui->setupUi(this);
//}

//login::~login()
//{
//    delete ui;
//}

//void login::on_play_clicked()
//{
//    main *m
////    Player *p = new Player(, 2);
////    p->show();
//}


//void login::on_levels_clicked()
//{

//}


//void login::on_exit_clicked()
//{

//}

