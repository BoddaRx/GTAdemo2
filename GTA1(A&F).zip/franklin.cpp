#include "franklin.h"

franklin::franklin()
{

}
