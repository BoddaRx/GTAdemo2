#ifndef FRANKLIN_H
#define FRANKLIN_H


class franklin
{
public:
    franklin();
};

#endif // FRANKLIN_H
